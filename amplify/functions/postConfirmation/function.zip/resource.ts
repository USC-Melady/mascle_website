import { defineFunction } from '@aws-amplify/backend';

export const postConfirmation = defineFunction({
  name: 'postConfirmation',
  entry: './handler.ts',
  environment: {
    // The function will use this table name
    USER_TABLE_NAME: 'User-val7xiyjy5bf5lxvmzbbmmaqaq-NONE'
  }
});
