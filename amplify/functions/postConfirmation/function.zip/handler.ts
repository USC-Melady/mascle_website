import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand } from '@aws-sdk/lib-dynamodb';
import { CognitoIdentityProviderClient, AdminAddUserToGroupCommand } from '@aws-sdk/client-cognito-identity-provider';
import type { PostConfirmationTriggerEvent } from 'aws-lambda';

// Initialize DynamoDB client
const ddbClient = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(ddbClient);

// Initialize Cognito client
const cognitoClient = new CognitoIdentityProviderClient({});

export const handler = async (event: PostConfirmationTriggerEvent) => {
  console.log('Post Confirmation Lambda triggered', event);

  try {
    const { userAttributes } = event.request;
    const { 
      sub, 
      email, 
      email_verified, 
      given_name, 
      family_name, 
      name, 
      phone_number, 
      'cognito:user_status': cognitoUserStatus 
    } = userAttributes;

    // 🔹 Read table name from the environment variable
    const USER_TABLE_NAME = process.env.USER_TABLE_NAME;

    if (!USER_TABLE_NAME) {
      console.error('USER_TABLE_NAME environment variable is not set');
      return event;
    }

    console.log('Using table name:', USER_TABLE_NAME);

    // Create user record with all available attributes
    const user = {
      id: sub, // Primary key
      userId: sub, // Keep for backward compatibility
      email: email,
      emailVerified: email_verified === 'true',
      status: cognitoUserStatus || 'CONFIRMED',
      roles: ['Student'], // Default role for new users
      
      // Personal information
      givenName: given_name || undefined,
      familyName: family_name || undefined,
      fullName: name || (given_name ? (family_name ? `${given_name} ${family_name}` : given_name) : undefined),
      phoneNumber: phone_number || undefined,
      
      // Metadata
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastLogin: new Date().toISOString()
    };

    console.log('Attempting to save user to DynamoDB:', user);

    try {
      // Save to DynamoDB
      await ddbDocClient.send(
        new PutCommand({
          TableName: USER_TABLE_NAME,
          Item: user
        })
      );
      console.log('User record created successfully in DynamoDB');
    } catch (dbError) {
      console.error('Error saving user to DynamoDB:', dbError);
      // Continue execution to try adding user to group
    }

    // Add user to Student group in Cognito
    try {
      console.log('Attempting to add user to Student group in Cognito');
      const addToStudentGroupCommand = new AdminAddUserToGroupCommand({
        UserPoolId: event.userPoolId,
        Username: event.userName,
        GroupName: 'Student'
      });

      await cognitoClient.send(addToStudentGroupCommand);
      console.log('Successfully added user to Student group in Cognito');
    } catch (groupError) {
      console.error('Error adding user to Student group:', groupError);
      // Don't throw here - we want to return the event even if group assignment fails
    }
  } catch (error) {
    console.error('Error in post-confirmation handler:', error);
  }

  // Always return the event to allow the authentication flow to continue
  return event;
};
